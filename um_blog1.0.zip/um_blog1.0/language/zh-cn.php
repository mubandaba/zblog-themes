<?php
return array(
	'author' => '作者',
	'view'=>'浏览',
	'date' => '日期',
    'category' => '分类',
	'comment' => '评论',
	'comment_list'=>'评论列表',
	'comment_post_on'=>'发布于',
	'reply'=>'回复该评论',
	'add_reply'=>'发表评论',
	'cancel_reply'=>'取消回复',
	'reply_notice'=>'◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。',
);