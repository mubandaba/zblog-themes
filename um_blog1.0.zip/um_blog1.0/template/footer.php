{* Template Name:公共底部 *}
</div></section><div class="clear"></div>
<div id="divBottom">
    <div class="text"><h4 id="BlogPowerBy">Powered By {$zblogphphtml}</h4><span>&nbsp;Theme By <a href="http://www.umhtml.com" title="优美尚品" target="_blank">优美尚品</a></span></div>
    <div class="text"><h3 id="BlogCopyRight">{$copyright}</h3>&nbsp;<span>{$zbp->Config('um_blog')->beian}</span></div>
</div>
{$zbp->Config('um_blog')->ftcode}
{$footer}
</body>
</html>