<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('wzdir')) {$zbp->ShowError(48);die();}
$blogtitle='ZBLOG导航主题配置';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';

if(isset($_POST['SetKeywords'])){
	$zbp->Config('wzdir')->SetKeywords = $_POST['SetKeywords'];
	$zbp->Config('wzdir')->SetDescription = $_POST['SetDescription'];
  $zbp->Config('wzdir')->SetHomeDir = $_POST['SetHomeDir'];
	$zbp->SaveConfig('wzdir');
	$zbp->ShowHint('good');
}
?>
<div id="divMain">
	<div class="divHeader"><?php echo $blogtitle;?></div>
	<div id="divMain2">
	<form id="form1" name="form1" method="post">	
    <table width="100%" style='padding:0;margin:0;' cellspacing='0' cellpadding='0' class="tableBorder">
  <tr>
    <th width="15%"><p align="center">项目名称</p></th>
    <th width="50%"><p align="center">文本/代码</p></th>
	<th width="25%"><p align="center">调用标签</p></th>
  </tr>
  <tr>
    <td><label for="SetKeywords"><p align="center">站点关键词</p></label></td>
    <td><p align="left"><textarea name="SetKeywords" type="text" id="SetKeywords" style="width:98%;"><?php echo $zbp->Config('wzdir')->SetKeywords;?></textarea></p></td>
	<td><p align="left">{$zbp->Config('wzdir')->SetKeywords}</p></td>
  </tr>
  <tr>
    <td><label for="SetDescription"><p align="center">站点描述</p></label></td>
    <td><p align="left"><textarea name="SetDescription" type="text" id="SetDescription" style="width:98%;"><?php echo $zbp->Config('wzdir')->SetDescription;?></textarea></p></td>
	<td><p align="left">{$zbp->Config('wzdir')->SetDescription}</p></td>
  </tr>
  <tr>
    <td><label for="SetHomeDir"><p align="center">首页目录分类</p></label></td>
    <td><p align="left"><textarea name="SetHomeDir" type="text" id="SetHomeDir" style="width:98%;"><?php echo $zbp->Config('wzdir')->SetHomeDir;?></textarea></p></td>
  <td><p align="left">设置首页显示分类ID，比如：1,2,3</p></td>
  </tr>
</table>
 <br />
   <input name="" type="Submit" class="button" value="保存主题设置内容"/>
    </form>
<br />
   <table width="100%" style='padding:0;margin:0;' cellspacing='0' cellpadding='0' class="tableBorder">
  <tr class="color2"><td style="text-align:center;line-height:40px;font-size:16px;">本免费ZBLOG PHP主题来自：<a href="https://www.laobuluo.com/" target="_blank" title="老部落">老部落</a> / <a href="https://www.itbulu.com/" target="_blank" title="老蒋部落">老蒋部落</a> / 加入站长技术交流QQ群： <a href="https://jq.qq.com/?_wv=1027&k=5EShrZo" target="_blank">1012423279</a></td></tr>
   <tr class="color1"><td style="text-align:center;line-height:40px;font-size:16px;">声明内容：免费分享ZBLOG导航主题，不可以用于违规和违法内容，使用主题的用户/站长自行承担责任。</td></tr>
  </table>
  
	</div>

</div>

<script type="text/javascript">ActiveTopMenu("topmenu_itbulu");</script> 
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>