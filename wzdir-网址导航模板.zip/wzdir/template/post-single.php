<div class="mianbao">当前位置：&nbsp;<a href='{$host}'>首页</a>{php}
$html='';
function navcate($id){
global $html;
$cate = new Category;
$cate->LoadInfoByID($id);
$html ='>> <a href="' .$cate->Url.'" title="查看' .$cate->Name. '中
的全部文章">' .$cate->Name. '</a> '.$html;
if(($cate->ParentID)>0){navcate($cate->ParentID);}
}
navcate($article->Category->ID);
global $html;
echo $html;
{/php}>>{$article.Title}</div>
<div class="page_content">
<div class="page_left">
<div>网站名称：{$article.Title}</div>	
<div>网站网址：<a href="http://{$article->Metas->articlesurl}" target="_blank">{$article->Metas->articlesurl}</a></div>
<div>网站介绍：{$article.Content}</div>	
</div>
<div class="page_right">
导航内容右侧广告
</div>
</div>
<section class="container" id="navs">		
<div class="suiji">
{$array=TcgetList(10,null,null,null,null,null,null,'rand');}
<h2>优秀网站推荐</h2>
<ul class="xoxo blogroll">
{foreach $array as $related}	
<li><a href="{$related.Url}" title="{$related.Title}" target="_blank">{$related.Title}</a><br>{$related->Metas->articlesinfo}</li>
{/foreach}
</ul>

</div>
</section>
{if !$article.IsLock}
{template:comments}
{/if}