<h2>{$article.Title}</h2>
<div class="page_content">
{$article.Content}
</div>
{if !$article.IsLock}
{template:comments}
{/if}