<?php
/**
Theme Name: WZDIR
Version: 1.0
Author: 老部落
Author URI: https://www.laohuluo.com
*/
?>
{template:header}
</head>
<body class="page page-id-5013 page-template page-template-pagesnav-php">
<div class="pageheader">
	<div class="container">
		
		<div class="logo"><a href="{$host}"><img src="{$host}zb_users/theme/{$theme}/style/images/logo.png" title="{$name}"></a></div>
		<div class="navbar">{module:navbar}</div>
	</div>
</div>
<section class="container" id="navs">	 
		
	<div class="items">
<div class="item item-0">
<h2>{$category.Name}</h2>
<ul class="xoxo blogroll">
{foreach $articles as $article}
{template:post-multi}
{/foreach}
</ul>
</div>
<div class="pagebar">{template:pagebar}</div>
</div>

</section>

{template:footer}