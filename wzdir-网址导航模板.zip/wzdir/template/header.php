<?php
/**
Theme Name: WZDIR
Version: 1.0
Author: 老部落
Author URI: https://www.laohuluo.com
*/
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=11,IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta http-equiv="Cache-Control" content="no-siteapp">
{if $type=='index'&&$page=='1'}
<title>{$name}_{$subname}</title>
<meta name="keywords" content="{$zbp->Config('wzdir')->SetKeywords}" />
<meta name="description" content="{$zbp->Config('wzdir')->SetDescription}" />
{elseif $type=='article'}
<title>{$title}_{$name}</title>
<meta name="description" content="{php}echo preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Content,'[nohtml]'),100)).'...');{/php}" />
{else}
<title>{$title}</title>    
{/if}
<meta name="generator" content="{$zblogphp}" />
<link rel="shortcut icon" href="{$host}zb_users/theme/{$theme}/style/images/favicon.ico">
<link rel="stylesheet" id="da-main-css" href="{$host}zb_users/theme/{$theme}/style/{$style}.css" type="text/css" media="all">
<script src="{$host}zb_system/script/common.js" type="text/javascript"></script>
<script src="{$host}zb_system/script/c_html_js_add.php" type="text/javascript"></script>
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="{$host}zb_system/xml-rpc/?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="{$host}zb_system/xml-rpc/wlwmanifest.xml" />
{$header}

 