<div id="footer">
<div class="container">
	<p>&copy; {$copyright} / Power By ZBLOG.</p>
</div>
</div>
{$footer}
</body>
</html>