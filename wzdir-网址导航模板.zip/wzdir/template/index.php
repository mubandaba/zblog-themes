<?php
/**
Theme Name: WZDIR
Version: 1.0
Author: 老部落
Author URI: https://www.laohuluo.com
*/
?>
{template:header}
</head>
<body class="page page-id-5013 page-template page-template-pagesnav-php">
<div class="pageheader">
	<div class="container">
		
		<div class="logo"><a href="{$host}"><img src="{$host}zb_users/theme/{$theme}/style/images/logo.png" title="{$name}"></a></div>
		<div class="navbar">{module:navbar}</div>
	</div>
</div>
<section class="container" id="navs">	 
	
	<div class="items">
{php}
$flids = explode(',',$zbp->Config('wzdir')->SetHomeDir);{/php}
{foreach $flids as $flid}
<div class="item item-0">
{foreach GetList(1,$flid) as $article}
<h2><a href="{$article.Category.Url}" title="{$article.Category.Name}">{$article.Category.Name}</a></h2>
{/foreach}
<ul class="xoxo blogroll">
{foreach GetList(5,$flid) as $key=>$article}	
<li><a href="{$article.Url}" title="{$article.Title}" target="_blank">{$article.Title}</a><br>{$article->Metas->articlesinfo}</li>
{/foreach}
</ul>
</div>
{/foreach}
</div>
</section>
{template:footer}